# 🚀 Kanban de Tarefas

Aplicação de Kanban simples feita com HTML, CSS e JavaScript.

## ✅ Funcionalidades
- Criar tarefas com:
  - Título
  - Prioridade (Alta, Média, Baixa)
  - Data de vencimento
- Três colunas: 📋 A Fazer, 🛠️ Em Andamento, ✅ Concluído
- Arrastar e soltar tarefas (Drag and Drop)
- Busca e filtro por prioridade
- Contagem de tarefas por coluna
- Tema claro/escuro (Dark Mode)
- Dados salvos no navegador (LocalStorage)

## 🚀 Como Executar Localmente
1. Baixe ou clone este repositório.
2. Abra o arquivo `index.html` no navegador.

## 🌐 Publicado em GitHub Pages
👉 [Acesse aqui](https://seu-usuario.github.io/kanban-tarefas/)

## 📄 Licença
MIT License.
