
// ========== Funções Principais ==========
document.getElementById('toggle-mode').addEventListener('click', () => {
    document.body.classList.toggle('dark');
});

loadTasks();
updateCounters();

function addTask() {
    const taskInput = document.getElementById('new-task');
    const dueDate = document.getElementById('due-date').value;
    const priority = document.getElementById('priority').value;
    const title = taskInput.value.trim();

    if (title === '') {
        alert('Digite uma tarefa.');
        return;
    }

    const task = createTaskElement(title, priority, dueDate);
    document.getElementById('todo').appendChild(task);
    saveTasks();
    updateCounters();

    taskInput.value = '';
    document.getElementById('due-date').value = '';
}

function createTaskElement(title, priority, dueDate) {
    const task = document.createElement('div');
    task.className = `task priority-${priority}`;
    task.draggable = true;
    task.ondragstart = drag;

    const top = document.createElement('div');
    top.className = 'top';

    const taskTitle = document.createElement('div');
    taskTitle.className = 'title';
    taskTitle.textContent = title;
    taskTitle.contentEditable = true;
    taskTitle.addEventListener('blur', saveTasks);

    const deleteBtn = document.createElement('button');
    deleteBtn.innerHTML = 'Excluir';
    deleteBtn.onclick = () => {
        task.remove();
        saveTasks();
        updateCounters();
    };

    top.appendChild(taskTitle);
    top.appendChild(deleteBtn);

    const meta = document.createElement('div');
    meta.className = 'meta';
    meta.innerHTML = `Prioridade: <strong>${priority}</strong> <br> Data: ${dueDate || 'Sem data'}`;

    if (dueDate && new Date(dueDate) < new Date().setHours(0, 0, 0, 0)) {
        meta.innerHTML += '<br><span class="overdue">⚠️ Atrasada</span>';
    }

    task.appendChild(top);
    task.appendChild(meta);

    return task;
}

// ========== Drag and Drop ==========
function allowDrop(ev) {
    ev.preventDefault();
}
function drag(ev) {
    ev.dataTransfer.setData('text', ev.target.outerHTML);
    ev.target.remove();
    updateCounters();
}
function drop(ev) {
    ev.preventDefault();
    const data = ev.dataTransfer.getData('text');
    ev.target.closest('.column').insertAdjacentHTML('beforeend', data);
    addDragEvents();
    saveTasks();
    updateCounters();
}

function addDragEvents() {
    const tasks = document.querySelectorAll('.task');
    tasks.forEach(task => {
        task.ondragstart = drag;
    });
}

// ========== Busca e Filtro ==========
function searchTasks() {
    const search = document.getElementById('search').value.toLowerCase();
    const filterPriority = document.getElementById('filterPriority').value;

    document.querySelectorAll('.task').forEach(task => {
        const title = task.querySelector('.title').textContent.toLowerCase();
        const priorityClass = task.className;

        const matchesSearch = title.includes(search);
        const matchesPriority = !filterPriority || priorityClass.includes(`priority-${filterPriority}`);

        if (matchesSearch && matchesPriority) {
            task.style.display = 'flex';
        } else {
            task.style.display = 'none';
        }
    });
}

// ========== Contagem ==========
function updateCounters() {
    ['todo', 'in-progress', 'done'].forEach(id => {
        const count = document.querySelectorAll(`#${id} .task`).length;
        document.getElementById(`count-${id}`).textContent = count;
    });
}

// ========== LocalStorage ==========
function saveTasks() {
    const board = {};
    ['todo', 'in-progress', 'done'].forEach(id => {
        board[id] = document.getElementById(id).innerHTML;
    });
    localStorage.setItem('kanbanBoard', JSON.stringify(board));
}

function loadTasks() {
    const data = JSON.parse(localStorage.getItem('kanbanBoard'));
    if (!data) return;
    ['todo', 'in-progress', 'done'].forEach(id => {
        document.getElementById(id).innerHTML = data[id];
    });
    addDragEvents();
}

// ========== Limpar Tudo ==========
function clearAll() {
    if (confirm('Deseja realmente apagar todas as tarefas?')) {
        ['todo', 'in-progress', 'done'].forEach(id => {
            document.getElementById(id).innerHTML = '';
        });
        saveTasks();
        updateCounters();
    }
}
